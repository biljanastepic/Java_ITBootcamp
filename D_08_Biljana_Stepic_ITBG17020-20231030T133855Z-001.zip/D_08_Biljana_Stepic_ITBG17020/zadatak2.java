package domaci.D_08_Biljana_Stepic_ITBG17020;

import java.util.ArrayList;

public class zadatak2 {
    //Napraviti funkciju koja prima listu celih brojeva i izbacuje iz nje sve elemente koji su deljivi sa 4.

    public static ArrayList<Integer> izbaciDeljiveSa4(ArrayList<Integer> lista) {
        ArrayList<Integer> novaLista = new ArrayList<>();

        for (int broj : lista) {
            if (broj % 4 != 0) {
                novaLista.add(broj);
            }
        }

        return novaLista;
    }

    public static void main(String[] args) {
        ArrayList<Integer> lista = new ArrayList<>();
        lista.add(4);
        lista.add(8);
        lista.add(12);
        lista.add(15);
        lista.add(16);

        ArrayList<Integer> konacnaLista = izbaciDeljiveSa4(lista);

        System.out.println("Originalna lista: " + lista);
        System.out.println("Filtrirana lista bez brojeva deljivih sa 4: " + konacnaLista);
    }
}




