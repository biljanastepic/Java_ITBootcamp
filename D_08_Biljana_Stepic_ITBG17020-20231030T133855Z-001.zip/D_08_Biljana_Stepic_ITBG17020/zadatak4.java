package domaci.D_08_Biljana_Stepic_ITBG17020;

import java.util.ArrayList;

public class zadatak4 {
    //Napraviti funkciju koja izbacuje svako pojavljivanje n u listi

    public static void izbaciElement(ArrayList<Integer> lista, int n) {
        lista.removeIf(e -> e == n);
    }

    public static void main(String[] args) {
        ArrayList<Integer> lista = new ArrayList<>();
        lista.add(2);
        lista.add(4);
        lista.add(3);
        lista.add(4);
        lista.add(5);
        lista.add(4);

        int izbaci = 4;

        izbaciElement(lista, izbaci);

        System.out.println("Lista nakon izbacivanja broja " + izbaci + ": " + lista);
    }
}
