package domaci.D_08_Biljana_Stepic_ITBG17020;

import java.util.ArrayList;

public class zadatak5 {
    //Kreirati klasu Korpa koja ima listu namirnica(String). Kreirati:
    //- metodu koja prima neku namirnicu i dodaje je u listu
    //- metodu koja za unetu namirnicu vraca true/false ukoliko se namirnica tu nalazi.
    //- metodu cenaKorpe koja vraca ukupnu cenu svih namirnica ako racunamo da je prosek jedne      namirnice 70 dinara
    //- metodu izlistaj koja prikazuje sve namirnice iz liste
    //Takodje kreirati potreban konstruktor, get i set metode kao i toString

    private ArrayList<String> namirnice;


    public void Korpa() {
        namirnice = new ArrayList<>();
    }


    public void dodajNamirnicu(String namirnica) {
        namirnice.add(namirnica);
    }


    public boolean sadrziNamirnicu(String namirnica) {
        return namirnice.contains(namirnica);
    }


    public double cenaKorpe() {
        return namirnice.size() * 70.0;
    }


    public void izlistaj() {
        for (String namirnica : namirnice) {
            System.out.println(namirnica);
        }
    }


    public ArrayList<String> getNamirnice() {
        return namirnice;
    }


    public void setNamirnice(ArrayList<String> namirnice) {
        this.namirnice = namirnice;
    }


    @Override
    public String toString() {
        return "Korpa sa " + namirnice.size() + " namirnica";
    }

    public static void main(String[] args) {
        ArrayList korpa = new ArrayList();

        korpa.add("Jabuka");
        korpa.add("Kruska");
        korpa.add("Banana");
        korpa.add("Jogurt");

        System.out.println("Sadrzaj korpe:" + korpa);


        String trazenaNamirnica = "Kruska";
        System.out.println("Da li se " + trazenaNamirnica + " nalazi u korpi? " + korpa.contains(trazenaNamirnica));

        System.out.println("Ukupna cena korpe: " + trazenaNamirnica + " dinara");
    }
}
