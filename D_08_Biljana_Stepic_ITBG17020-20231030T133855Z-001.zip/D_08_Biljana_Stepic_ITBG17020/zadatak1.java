package domaci.D_08_Biljana_Stepic_ITBG17020;

import java.util.ArrayList;
public  class zadatak1 {

public static ArrayList<Integer> parnaLista() {
        ArrayList<Integer> parniBrojevi = new ArrayList<>();

        int broj = 2; // pocetni parni broj
        int brojElemenata = 30; //  broj elemenata u listi

        while (parniBrojevi.size() < brojElemenata) {
        parniBrojevi.add(broj);
        broj += 2; // sledeci parni broj
        }

        return parniBrojevi;
        }

public static void main(String[] args) {
        ArrayList<Integer> listaParnihBrojeva = parnaLista();

        System.out.println("Lista parnih brojeva:");
        for (int broj : listaParnihBrojeva) {
        System.out.print(broj + " ");
        }
        }

}

