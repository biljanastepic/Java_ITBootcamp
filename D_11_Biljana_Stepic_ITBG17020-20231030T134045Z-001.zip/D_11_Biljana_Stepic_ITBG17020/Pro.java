package D_11_Biljana_Stepic_ITBG17020;

public class Pro extends Planinar{
    public Pro(String ime){
        super(ime,3000);
    }
}
