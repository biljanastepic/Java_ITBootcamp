package D_11_Biljana_Stepic_ITBG17020;

public class TestPlanina {
    public static void main(String[] args) {
        Planina planina1 = new Planina("Tara", 1570);
        Planina planina2 = new Planina("Kopaonik", 2017);
        Planina planina3 = new Planina("Sar planina", 3001);

        Amater amater = new Amater("Stefan");
        amater.popniSe(planina1);
        amater.popniSe(planina2);
        System.out.println(amater);
        System.out.println("Crna lista za amatera: " + amater.crnaLista());
        System.out.println("Ukupno metara za amatera: " + amater.ukupnoMetara());


        Rekreativac rekreativac = new Rekreativac("Marijana");
        rekreativac.popniSe(planina1);
        rekreativac.popniSe(planina3);
        System.out.println(rekreativac);
        System.out.println("Crna lista za rekreativca je: " + rekreativac.crnaLista());
        System.out.println("Ukupno metara za amatera: " + rekreativac.ukupnoMetara());

        Pro pro = new Pro("Mladen");
        pro.popniSe(planina1);
        pro.popniSe(planina2);
        pro.popniSe(planina3);
        System.out.println(pro);
        System.out.println("Crna lista za pro-a je: " + pro.crnaLista());
        System.out.println("Ukupno metara za amatera: " + pro.ukupnoMetara());



    }
}
