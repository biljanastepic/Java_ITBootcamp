package D_11_Biljana_Stepic_ITBG17020;

public class Planina {
    private String nazivPlanine;
    private int visinaPlanine;

    public Planina(String nazivPlanine, int visinaPlanine) {
        this.nazivPlanine = nazivPlanine;
        this.visinaPlanine = visinaPlanine;
    }

    public String getNazivPlanine() {
        return nazivPlanine;
    }

    public void setNazivPlanine(String nazivPlanine) {
        this.nazivPlanine = nazivPlanine;
    }

    public int getVisinaPlanine() {
        return visinaPlanine;
    }

    public void setVisinaPlanine(int visinaPlanine) {
        this.visinaPlanine = visinaPlanine;
    }

    @Override
    public String toString() {
        return "Planina{" +
                "naziv='" + nazivPlanine + '\'' +
                ", visina=" + visinaPlanine +
                '}';
    }
}
