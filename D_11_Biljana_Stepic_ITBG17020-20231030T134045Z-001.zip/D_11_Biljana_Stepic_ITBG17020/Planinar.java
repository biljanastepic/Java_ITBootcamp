package D_11_Biljana_Stepic_ITBG17020;

import java.util.ArrayList;
import java.util.List;

public abstract class Planinar {
    protected String imePlaninara;
    protected List<Planina> listaPlanina;
    protected int maximalnaVisina;

    public Planinar(String imePlaninara, int maximalnaVisina) {
        this.imePlaninara = imePlaninara;
        this.maximalnaVisina = maximalnaVisina;
        this.listaPlanina = new ArrayList<>();
    }
    public void popniSe(Planina planina){
        if(planina.getVisinaPlanine() <= maximalnaVisina && !listaPlanina.contains(planina)){
            listaPlanina.add(planina);
        }else{
            System.out.println("Planinar " + imePlaninara + " ne moze da se popne na planinu " + planina.getNazivPlanine());
        }
    }
    public List<Planina> crnaLista(){
        List<Planina> crnaLista = new ArrayList<>();
        for(Planina planina : listaPlanina){
            if(planina.getVisinaPlanine() > maximalnaVisina){
                crnaLista.add(planina);
            }
        }
        return crnaLista;
    }
    public int ukupnoMetara(){
        int ukupnaVisina = 0;
        for (Planina planina : listaPlanina){
            ukupnaVisina += planina.getVisinaPlanine();
        }
        return  ukupnaVisina;
    }

    public String getImePlaninara() {
        return imePlaninara;
    }

    public void setImePlaninara(String imePlaninara) {
        this.imePlaninara = imePlaninara;
    }

    public List<Planina> getListaPlanina() {
        return listaPlanina;
    }

    public void setListaPlanina(List<Planina> listaPlanina) {
        this.listaPlanina = listaPlanina;
    }

    public int getMaximalnaVisina() {
        return maximalnaVisina;
    }

    public void setMaximalnaVisina(int maximalnaVisina) {
        this.maximalnaVisina = maximalnaVisina;
    }

    @Override
    public String toString() {
        return "Planinar{" +
                "ime='" + imePlaninara + '\'' +
                ", listaPlanina=" + listaPlanina +
                ", maxVisina=" + maximalnaVisina +
                '}';
    }
}

