package D_11_Biljana_Stepic_ITBG17020;

 class Amater extends Planinar{
     public Amater(String ime){
         super(ime,1000);
     }

}
