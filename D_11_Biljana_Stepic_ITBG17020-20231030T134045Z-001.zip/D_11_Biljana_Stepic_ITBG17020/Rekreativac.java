package D_11_Biljana_Stepic_ITBG17020;

public class Rekreativac extends Planinar{
    public Rekreativac(String ime){
        super(ime,2000);
    }
}
