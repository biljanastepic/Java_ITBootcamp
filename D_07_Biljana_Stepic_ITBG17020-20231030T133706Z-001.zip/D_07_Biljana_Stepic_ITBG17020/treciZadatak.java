package domaci.D_07_Biljana_Stepic_ITBG17020;

public class treciZadatak {
    //Napraviti funkciju koja prima niz Stringova nekih imena i kao rezultat vraca broj duplikata
    //imena(Ukoliko ih ima).

    public static int brojDuplikata(String[] imena) {
        int brojDuplikata = 0;

        for (int i = 0; i < imena.length; i++) {
            for (int j = i + 1; j < imena.length; j++) {
                if (imena[i].equals(imena[j])) {
                    brojDuplikata++;
                    break;
                }
            }
        }

        return brojDuplikata;
    }
}
