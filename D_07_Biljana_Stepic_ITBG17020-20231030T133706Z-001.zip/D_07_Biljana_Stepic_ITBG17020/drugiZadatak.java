package domaci.D_07_Biljana_Stepic_ITBG17020;

public class drugiZadatak {
    //Napraviti funkciju koja prima dva niza celih brojeva jednake duzine i kao rezultat vraca zbir
    //svih elemenata na istoj poziciji
    public static int[] zbir(int[] niz1, int[] niz2){

        int[] zbirBrojeva = new int[niz1.length];
        if (niz1.length != niz2.length)
            return new int[0];

        for (int i = 0; i < niz1.length; i++) {
            zbirBrojeva[i] = niz1[i] + niz2[i];
        }
        return zbirBrojeva;

    }
}

