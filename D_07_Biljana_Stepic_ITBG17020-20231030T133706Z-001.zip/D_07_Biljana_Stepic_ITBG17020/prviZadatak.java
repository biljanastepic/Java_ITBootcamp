package domaci.D_07_Biljana_Stepic_ITBG17020;

import java.util.Scanner;

public class prviZadatak {
    public static boolean daLiSuNizoviJednaki(int[] niz1, int[] niz2) {
        if (niz1.length != niz2.length) {
            return false;
        }

        for (int i = 0; i < niz1.length; i++) {
            if (niz1[i] != niz2[i]) {
                return false;
            }
        }

        return true;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Unesite dužinu prvog niza:");
        int duzina = sc.nextInt();

        int[] niz1 = new int[duzina];

        System.out.println("Unesite dužinu drugog niza:");
        int duzina2 = sc.nextInt();
        int[] niz2 = new int[duzina2];

        System.out.println("Unesite elemente prvog niza:");
        for (int i = 0; i < duzina; i++) {
            niz1[i] = sc.nextInt();
        }

        System.out.println("Unesite elemente drugog niza:");
        for (int i = 0; i < duzina2; i++) {
            niz2[i] = sc.nextInt();
        }
        boolean rezultat = daLiSuNizoviJednaki(niz1, niz2);

        if (rezultat) {
            System.out.println("Nizovi su jednaki.");
        } else {
            System.out.println("Nizovi nisu jednaki.");
        }
    }
}

