package D_10_1_Biljana_Stepic_ITBG17020;

import java.util.ArrayList;

public class Salon{
    private ArrayList<Automobil> listaAutomobila;

    public Salon(ArrayList<Automobil> listaAutomobila) {
        this.listaAutomobila = listaAutomobila;
    }

    public Automobil vratiNajstariji() {
        Automobil najstariji = null;
        int najstarijeGodiste = Integer.MAX_VALUE;

        for (Automobil automobil : listaAutomobila) {
            if (automobil.getGodiste() < najstarijeGodiste) {
                najstarijeGodiste = automobil.getGodiste();
                najstariji = automobil;
            }
        }

        return najstariji;
    }

    public Automobil vratiNajskuplji() {
        Automobil najskuplji = null;
        double najvecaCena = Double.MIN_VALUE;

        for (Automobil automobil : listaAutomobila) {
            if (automobil.getCena() > najvecaCena) {
                najvecaCena = automobil.getCena();
                najskuplji = automobil;
            }
        }

        return najskuplji;
    }
}
