package D_10_1_Biljana_Stepic_ITBG17020;

import java.util.ArrayList;

public class Audi extends Automobil {
    public Audi(ArrayList<Tocak> listaTockova, int godiste, double cena) {
        super(listaTockova, godiste, cena);
    }

    @Override
    public boolean vratiOstecene(Tocak tocak) {
        int starostGranica = 60;
        return tocak.getTrajanjeTocka() > starostGranica;
    }

    @Override
    public double cenaTockova() {
        double cenaPoTocku = 110;
        return cenaPoTocku * getListaTockova().size();
    }
}
