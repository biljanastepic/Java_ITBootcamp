package D_09_Biljana_Stepic_ITBG17020;

public class Srpski extends Predmet {
    public Srpski(String naziv, int ocena) {
        super(naziv, ocena);
    }
}
