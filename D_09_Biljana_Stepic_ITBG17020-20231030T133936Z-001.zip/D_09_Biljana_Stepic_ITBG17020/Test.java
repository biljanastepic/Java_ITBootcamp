package D_09_Biljana_Stepic_ITBG17020;

public class Test {
    public static void main(String[] args) {
        Skola skola = new Skola();

        Ucenik ucenik1 = new Ucenik(3);
        ucenik1.dodajPredmet(new Matematika("Matematika", 9));
        ucenik1.dodajPredmet(new Srpski("Srpski", 8));

        Ucenik ucenik2 = new Ucenik(3);
        ucenik2.dodajPredmet(new Biologija("Biologija", 7));
        ucenik2.dodajPredmet(new Srpski("Srpski", 8));

        Ucenik ucenik3 = new Ucenik(4);
        ucenik3.dodajPredmet(new Matematika("Matematika", 9));
        ucenik3.dodajPredmet(new Biologija("Biologija", 10));

        skola.dodajUcenika(ucenik1);
        skola.dodajUcenika(ucenik2);
        skola.dodajUcenika(ucenik3);

        System.out.println("Prosek po godini 3: " + skola.prosekPoGodini(3));
        System.out.println("Prosek po predmetu 'Matematika': " + skola.prosekPoPredmetu("Matematika"));
        Ucenik ucenikSaNajmanjimProsekom = skola.ucenikSaNajmanjimProsekom();
        System.out.println("Učenik sa najmanjim prosekom: " + ucenikSaNajmanjimProsekom);
    }
}
