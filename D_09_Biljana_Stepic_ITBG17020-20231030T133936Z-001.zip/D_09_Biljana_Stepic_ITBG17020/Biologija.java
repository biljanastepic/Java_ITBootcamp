package D_09_Biljana_Stepic_ITBG17020;

public class Biologija extends  Predmet{
        public Biologija(String naziv, int ocena) {
            super(naziv, ocena);
        }
}
