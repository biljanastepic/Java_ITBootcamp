package D_09_Biljana_Stepic_ITBG17020;

public class Predmet {
    private String naziv;
    private int ocena;

    public Predmet(String naziv, int ocena) {
        this.naziv = naziv;
        this.ocena = ocena;
    }

    public String getNaziv() {
        return naziv;
    }

    public int getOcena() {
        return ocena;
    }
}
