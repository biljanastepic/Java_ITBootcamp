package D_09_Biljana_Stepic_ITBG17020;

import java.util.ArrayList;

public class Skola {
    private ArrayList<Ucenik> ucenici;

    public Skola() {
        this.ucenici = new ArrayList<>();
    }

    public void dodajUcenika(Ucenik ucenik) {
        ucenici.add(ucenik);
    }

    public double prosekPoGodini(int godina) {
        int brojac = 0;
        double sumaProsek = 0.0;

        for (Ucenik ucenik : ucenici) {
            if (ucenik.getGodinaSkolovanja() == godina) {
                sumaProsek += ucenik.izracunajProsek();
                brojac++;
            }
        }

        if (brojac == 0) {
            return 0.0;
        }

        return sumaProsek / brojac;
    }

    public double prosekPoPredmetu(String predmet) {
        int brojac = 0;
        double sumaProsek = 0.0;

        for (Ucenik ucenik : ucenici) {
            for (Predmet p : ucenik.getPredmeti()) {
                if (p.getNaziv().equals(predmet)) {
                    sumaProsek += ucenik.izracunajProsek();
                    brojac++;
                    break;
                }
            }
        }

        if (brojac == 0) {
            return 0.0;
        }

        return sumaProsek / brojac;
    }

    public Ucenik ucenikSaNajmanjimProsekom() {
        if (ucenici.isEmpty()) {
            return null;
        }

        Ucenik ucenikSaNajmanjimProsekom = ucenici.get(0);
        double najmanjiProsek = ucenikSaNajmanjimProsekom.izracunajProsek();

        for (Ucenik ucenik : ucenici) {
            double prosek = ucenik.izracunajProsek();
            if (prosek < najmanjiProsek) {
                najmanjiProsek = prosek;
                ucenikSaNajmanjimProsekom = ucenik;
            }
        }

        return ucenikSaNajmanjimProsekom;
    }
}
