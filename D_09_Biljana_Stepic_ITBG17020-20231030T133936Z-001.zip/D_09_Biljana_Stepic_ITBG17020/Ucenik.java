package D_09_Biljana_Stepic_ITBG17020;

import java.util.ArrayList;

public class Ucenik {
    private ArrayList<Predmet> predmeti;
    private int godinaSkolovanja;

    public Ucenik(int godinaSkolovanja) {
        this.predmeti = new ArrayList<>();
        this.godinaSkolovanja = godinaSkolovanja;
    }

    public ArrayList<Predmet> getPredmeti() {
        return predmeti;
    }

    public void setPredmeti(ArrayList<Predmet> predmeti) {
        this.predmeti = predmeti;
    }

    public void setGodinaSkolovanja(int godinaSkolovanja) {
        this.godinaSkolovanja = godinaSkolovanja;
    }

    public void dodajPredmet(Predmet predmet) {
        predmeti.add(predmet);
    }

    public double izracunajProsek() {
        if (predmeti.isEmpty()) {
            return 0.0; // Ako nema predmeta nema ni prosecne ocene, tjst prosečna ocena je 0.
        }

        int sumaOcena = 0;
        for (Predmet predmet : predmeti) {
            sumaOcena += predmet.getOcena();
        }

        return (double) sumaOcena / predmeti.size();
    }

    public int getGodinaSkolovanja() {
        return godinaSkolovanja;
    }


}
