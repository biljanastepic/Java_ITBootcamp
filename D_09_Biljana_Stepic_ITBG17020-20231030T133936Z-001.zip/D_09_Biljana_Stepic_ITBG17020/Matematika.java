package D_09_Biljana_Stepic_ITBG17020;

public class Matematika extends Predmet {
    public Matematika(String naziv, int ocena) {
        super(naziv, ocena);
    }
}
