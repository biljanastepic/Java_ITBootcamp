package D_10_Biljana_Stepic_ITBG17020;

import java.util.ArrayList;

public class BMW extends Automobil {
    public BMW(ArrayList<Tocak> listaTockova, int godiste, double cena) {
        super(listaTockova, godiste, cena);
    }
}
