package D_10_Biljana_Stepic_ITBG17020;

import java.util.ArrayList;

public class Automobil {
    private ArrayList<Tocak> listaTockova;
    private int godiste;
    private double cena;

    public Automobil(ArrayList<Tocak> listaTockova, int godiste, double cena) {
        this.listaTockova = listaTockova;
        this.godiste = godiste;
        this.cena = cena;
    }



    public ArrayList<Tocak> getListaTockova() {
        return listaTockova;
    }

    public void setListaTockova(ArrayList<Tocak> listaTockova) {
        this.listaTockova = listaTockova;
    }

    public int getGodiste() {
        return godiste;
    }

    public void setGodiste(int godiste) {
        this.godiste = godiste;
    }

    public double getCena() {
        return cena;
    }

    public void setCena(double cena) {
        this.cena = cena;
    }

    public boolean vratiOstecene(Tocak tocak) {

        int starostGranica = (this instanceof Audi) ? 60 : ((this instanceof BMW || this instanceof Mercedes) ? 100 : 0);
        return tocak.getTrajanjeTocka() > starostGranica;
    }

    public double cenaTockova() {

        double cenaPoTocku = (this instanceof BMW) ? 100 : ((this instanceof Mercedes) ? 120 : ((this instanceof Audi) ? 110 : 0));
        return cenaPoTocku * listaTockova.size();
    }

    public void zameniTocak() {

        int starostGranica = (this instanceof Audi) ? 60 : ((this instanceof BMW || this instanceof Mercedes) ? 100 : 0);
        for (Tocak tocak : listaTockova) {
            if (tocak.getTrajanjeTocka() > starostGranica) {
                System.out.println("Tocak zamenjen.");
                tocak.setTrajanjeTocka(0);
            }
        }
    }

    @Override
    public String toString() {
        return "Automobil [listaTockova=" + listaTockova + ", godiste=" + godiste + ", cena=" + cena + "]";
    }
}
