package D_10_Biljana_Stepic_ITBG17020;

import java.util.ArrayList;

public class Mercedes extends Automobil {
    public Mercedes(ArrayList<Tocak> listaTockova, int godiste, double cena) {
        super(listaTockova, godiste, cena);
    }
}
