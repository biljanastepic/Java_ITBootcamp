package domaci.br1;

import java.util.Scanner;

public class prviZadatak {
    public static void main(String[] args) {
        /*Napisati program gde korisnik unosi svoj broj godina. Ukoliko ima 18 ili vise godina, ispisati
          poruku da korisnik sme da konzumira alkohol, u suprotnom ispisati neku drugu poruku.
        */

        Scanner sc = new Scanner(System.in);

        System.out.print("Unesite broj godina: ");
        int brojGodina = sc.nextInt();

        if (brojGodina >= 18) {
            System.out.println("Korisnik sme da konzumira alkohol.");
        } else {
            System.out.println("Korisnik nije dovoljno star za konzumiranje alkohola.");
        }

    }
}
