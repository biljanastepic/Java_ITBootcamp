package domaci.br1;

import java.util.Scanner;

public class treciZadatak {
    public static void main(String[] args) {
        /*
        Napisati program gde korisnik unosi dva realna broja, zatim unosi naziv operacije koju zeli
        da izvrsi nad tim brojevima(sabiranje, oduzimanje, mnozenje, deljenje), zatim istampati
        rezultat date operacije
        */
        Scanner sc = new Scanner(System.in);

        System.out.print("Unesite prvi realan broj: ");
        double a = sc.nextDouble();

        System.out.print("Unesite drugi realan broj: ");
        double b = sc.nextDouble();

        System.out.print("Unesite naziv operacije (sabiranje, oduzimanje, mnozenje, deljenje): ");
        sc.nextLine();

        String operacija = sc.nextLine();

        double rezultat = 0;

        switch (operacija.toLowerCase()) {
            case "sabiranje":
                rezultat = a + b;
                System.out.print("a + b =" + a + b );
                break;
            case "oduzimanje":
                rezultat = a - b;
                System.out.print( a - b );
                break;
            case "mnozenje":
                rezultat = a * b;
                System.out.print("a * b =" + a * b );
                break;
            case "deljenje":
                if (b!= 0) {
                    rezultat = a / b;
                    System.out.println("a / b =" + a / b );
                } else
                {
                    System.out.println("Deljenje sa nulom nije dozvoljeno.");
                    sc.close();

                }
                System.out.println("Rezultat " + operacija + " je: " + rezultat);

        }
    }
}
