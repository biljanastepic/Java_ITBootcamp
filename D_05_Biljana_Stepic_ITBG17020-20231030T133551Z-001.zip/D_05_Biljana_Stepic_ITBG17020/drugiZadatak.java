package domaci.br1;

import java.util.Scanner;

public class drugiZadatak {
    public static void main(String[] args) {

        /*Napisati program gde korisnik unosi ceo broj, ukoliko je broj paran, promeniti ga u neparan i
        istampati, ukoliko je neparan, samo ispisati poruku da je u pitanju neparan broj.
        */

        Scanner sc = new Scanner(System.in);
        System.out.print("Unesite ceo broj: ");
        int broj = sc.nextInt();

        if (broj % 2 == 0) {
            broj++;
            System.out.println("Promenjen paran broj u neparan je: " + broj);
        } else {
            System.out.println("Neparan broj.");
        }


    }
}
