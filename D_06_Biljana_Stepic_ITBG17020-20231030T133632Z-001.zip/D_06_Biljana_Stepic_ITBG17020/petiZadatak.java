package domaci.br2;

import java.util.Scanner;

public class petiZadatak {
    //Napraviti niz brojeva i kao rezultat vratiti sumu svih parnih brojeva iz tog niza.

    public static void main(String[] args) {
        // niz brojeva
        int[] nizBrojeva = new int[100];
        for (int i = 0; i < 100; i++) {
            nizBrojeva[i] = i + 1;
        }

        // zbir parnih brojeva
        int sum = 0;
        for (int broj : nizBrojeva) {
            if (broj % 2 == 0) {
                sum += broj;
            }
        }

        // ispis rezultata
        System.out.println("Zbir parnih brojeva: " + sum);
    }
}
