package domaci.br2;

public class sestiZadatak {
    //Napisati funkciju koja ce za prosledjeni String da vrati broj samoglasnika u tom Stringu
    //(Koristiti .charAt(index) da pristupite svakom pojedinacnom karakteru iz Stringa)

        public static void main(String[] args) {
            String inputString = "papagaj";
            int brojSamoglasnika = samoglasnik(inputString);
            System.out.println("Broj samoglasnika je: " + brojSamoglasnika);
        }

        public static int samoglasnik(String str) {
            int count = 0;
            for (int i = 0; i < str.length(); i++) {
                char ch = Character.toLowerCase(str.charAt(i));
                if (ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u' || ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U'){
                    count++;
                }
            }
            return count;
        }
    }

