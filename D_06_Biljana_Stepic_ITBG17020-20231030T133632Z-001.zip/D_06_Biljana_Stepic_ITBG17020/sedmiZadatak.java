package domaci.br2;

public class sedmiZadatak {

    public static void main(String[] args) {
        int[] niz = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15};
        int pronadjiBroj = 25;

        locirajBroj(niz, pronadjiBroj);
    }
        public static void locirajBroj(int[] broj, int trazeniBroj) {
            for (int num : broj) {
                if (num == trazeniBroj) {
                    System.out.println("Pronađen je zadati broj " + trazeniBroj);
                    return;
                }
                System.out.println("Pogrešan element: " + num);
            }
            System.out.println("Zadati broj " + trazeniBroj + " nije pronađen u nizu.");
        }
    }

