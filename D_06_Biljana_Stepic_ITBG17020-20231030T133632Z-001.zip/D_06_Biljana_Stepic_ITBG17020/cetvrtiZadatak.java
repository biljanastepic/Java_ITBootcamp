package domaci.br2;

import java.util.Scanner;

public class cetvrtiZadatak {
    //Napraviti niz brojeva kroz koji cete proci i istampati samo neparne brojeve
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int[] nizBrojeva = new int[100];
        for (int i = 0; i < 100; i++) {
            nizBrojeva[i] = i + 1;
        }

        System.out.println("Neparni brojevi su: ");
        for (int broj : nizBrojeva) {
            if (broj % 2 != 0) {
                System.out.println(broj);
            }
        }
    }
}

