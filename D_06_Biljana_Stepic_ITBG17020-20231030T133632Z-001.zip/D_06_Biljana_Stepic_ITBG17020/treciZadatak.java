package domaci.br2;

import java.util.Scanner;

public class treciZadatak {
    //Napraviti program gde cete unositi neki tekst sve dok se ne unese tacka("."), cim se unese
    //tacka program se zavrsava i vraca prethodno unete tekstove.

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        String[] unetiTekstovi = new String[100];
        int brojac = 0;

        System.out.println("Unesi tekstove (unesi '.' za kraj):");

        while (true) {
            String unos = sc.nextLine();

            if (unos.equals(".")) {
                break;
            }

            unetiTekstovi[brojac] = unos;
            brojac++;
        }

        System.out.println("Prethodno uneti tekstovi:");
        for (int i = 0; i < brojac; i++) {
            System.out.println(unetiTekstovi[i]);
        }


    }
    }


