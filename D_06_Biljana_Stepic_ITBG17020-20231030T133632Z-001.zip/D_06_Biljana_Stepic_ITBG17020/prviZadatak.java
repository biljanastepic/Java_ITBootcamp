package domaci.br2;

import java.util.Scanner;

public class prviZadatak {
    //Zadatak 1:
   // Napraviti program gde cete uneti neki broj ponavljanja i tekst koji ce se toliko puta ispisati.
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        int i = 0;

        while (i < n) {
            System.out.println("Dobar dan.");
             i++;

        }
    }
}
